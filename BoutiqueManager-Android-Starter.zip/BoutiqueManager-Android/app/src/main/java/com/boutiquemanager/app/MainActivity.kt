package com.boutiquemanager.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val items = mutableListOf<String>()
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL

        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xFFF7F4F7.toInt())
        }
        scroll.addView(page)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "مدير البوتيك"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF38263A.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "إدارة محلات تأجير الفساتين"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        page.addView(subtitle, matchWrap())

        val heading = TextView(this).apply {
            text = "إضافة فستان"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(heading, matchWrap())

        val name = EditText(this).apply { hint = "اسم أو رقم الفستان" }
        page.addView(name, matchWrap())

        val size = EditText(this).apply { hint = "المقاس (اختياري)" }
        page.addView(size, matchWrap())

        val color = EditText(this).apply { hint = "اللون (اختياري)" }
        page.addView(color, matchWrap())

        val add = Button(this).apply {
            text = "إضافة الفستان"
            setOnClickListener {
                val value = name.text.toString().trim()
                if (value.isEmpty()) {
                    Toast.makeText(this@MainActivity, "اكتب اسم أو رقم الفستان", Toast.LENGTH_SHORT).show()
                } else {
                    val details = listOf(value, size.text.toString().trim(), color.text.toString().trim())
                        .filter { it.isNotEmpty() }.joinToString(" • ")
                    items.add(details)
                    refreshList()
                    name.text.clear()
                    size.text.clear()
                    color.text.clear()
                }
            }
        }
        page.addView(add, matchWrap())

        val listTitle = TextView(this).apply {
            text = "قائمة الفساتين"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 28, 0, 8)
        }
        page.addView(listTitle, matchWrap())

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(list, matchWrap())
        refreshList()

        val note = TextView(this).apply {
            text = "هذه نسخة أولية للتجربة. البيانات الحالية محفوظة أثناء تشغيل التطبيق فقط."
            textSize = 13f
            setPadding(0, 28, 0, 8)
        }
        page.addView(note, matchWrap())
    }

    private fun refreshList() {
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد فساتين بعد"
                textSize = 16f
                setPadding(8, 12, 8, 12)
            })
        } else {
            items.forEachIndexed { index, item ->
                list.addView(TextView(this).apply {
                    text = "${index + 1}. $item"
                    textSize = 17f
                    setPadding(12, 14, 12, 14)
                    setBackgroundColor(0xFFFFFFFF.toInt())
                }, matchWrap())
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }
}
