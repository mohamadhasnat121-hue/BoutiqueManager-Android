# Boutique Manager - Android starter

Arabic Android starter project for the Boutique Manager app.

## Build on GitHub
1. Upload the **contents** of this folder to the root of a new GitHub repository (do not upload the ZIP as a single file).
2. Open the repository's **Actions** tab.
3. Select **Build Boutique Manager APK** and press **Run workflow**, or push a commit to `main`.
4. When the run succeeds, open it and download the artifact named `BoutiqueManager-debug-apk`.
5. Extract the artifact ZIP; install `app-debug.apk` on an Android phone.

## Current prototype
- Arabic RTL home screen
- Add and list dress records (prototype data is in memory only)

This is only a starter prototype. It does not yet include persistent storage, reservations, customer records, subscriptions, cloud sync, or production signing.
